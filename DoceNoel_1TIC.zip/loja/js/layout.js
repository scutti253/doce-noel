// ===== Doce Noel - layout.js =====
// Cabeçalho, menu, rodapé, botão "voltar ao topo" e janela modal são iguais em todas as páginas.
// Em vez de copiar esse HTML 5 vezes, ele é escrito UMA vez aqui e colocado em cada página.
const paginas = [["index.html", "Home"], ["produtos.html", "Produtos"], ["sobre.html", "Sobre nós"], ["galeria.html", "Galeria"], ["contato.html", "Contato"]];
const atual = location.pathname.split("/").pop() || "index.html"; // nome da página aberta
const menu = paginas.map(([url, nome]) => `<a href="${url}"${url === atual ? ' class="ativo"' : ""}>${nome}</a>`).join("");

const principal = document.querySelector("main");
principal.insertAdjacentHTML("beforebegin", `
<header>
  <img src="img/logo.svg" alt="Logotipo da Doce Noel">
  <div class="controles"><button id="btn-musica">🎵 Tocar música</button><button id="btn-tema">🌙 Tema</button><span>🛒 <span id="qtd-carrinho">0</span></span><button class="btn-menu" aria-label="Abrir menu">☰</button></div>
  <nav class="menu">${menu}</nav>
</header>`);
principal.insertAdjacentHTML("afterend", `
<footer><p>&copy; 2026 Doce Noel · O sabor do Natal na sua mesa. Ilustrações e sons criados pela equipe.</p></footer>
<button id="topo" aria-label="Voltar ao topo">↑</button>
<div id="modal" class="modal"><div class="modal-c"><button id="fechar" aria-label="Fechar">✕</button><div id="modal-corpo"></div></div></div>`);
