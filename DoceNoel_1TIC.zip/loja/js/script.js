// ===== Doce Noel - script.js (JavaScript puro, sem bibliotecas) =====
const $ = s => document.querySelector(s);
const topo = $("#topo");
const preco = v => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

// Se uma foto não carregar, troca por uma imagem neutra (sem emoji) uma única vez
document.addEventListener("error", e => {
  const i = e.target;
  if (i.tagName === "IMG" && i.closest("main") && !i.dataset.falhou) { i.dataset.falhou = "1"; i.src = "img/produtos/sem-foto.svg"; }
}, true);

// Funções reaproveitadas em vários lugares (escritas uma vez só)
const achar = id => produtos.find(p => p.id == id);
const foto = (p, extra = "") => `<img src="${p.imagem}" alt="${p.nome}" ${extra}>`;

// [4] CARDS DINÂMICOS: cada produto do array vira um card (map + join)
const criarCard = (p, classe = "") => `<article class="card ${classe}">${foto(p, 'loading="lazy"')}
 <h3>${p.nome}</h3><p>${p.descricao}</p><strong>${preco(p.preco)}</strong>
 <div class="acoes"><button class="btn-comprar botao" data-id="${p.id}">Adicionar ao carrinho</button>
 <button class="btn-detalhe botao-claro" data-id="${p.id}">Detalhes</button></div></article>`;
const mostrar = (lista, el) => { el.innerHTML = lista.length ? lista.map((p, i) => criarCard(p, el.id === "destaques" ? "card-destaque" : "")).join("") : '<p class="vazio">🎄 Nenhum produto encontrado</p>'; };

// Destaques na Home
const dest = $("#destaques");
if (dest) mostrar([...produtos].sort((a, b) => b.preco - a.preco).slice(0, 4), dest);

// [5] FILTRO E BUSCA: filtra o array completo a cada digitação/mudança
const lista = $("#lista-produtos");
if (lista) {
  const busca = $("#busca"), sel = $("#categoria"), cont = $("#contador");
  [...new Set(produtos.map(p => p.categoria))].forEach(c => sel.insertAdjacentHTML("beforeend", `<option>${c}</option>`));
  const filtrar = () => {
    const t = busca.value.toLowerCase(), c = sel.value;
    const r = produtos.filter(p => p.nome.toLowerCase().includes(t) && (c === "todas" || p.categoria === c));
    mostrar(r, lista);
    cont.textContent = `Mostrando ${r.length} de ${produtos.length} produtos`;
  };
  busca.addEventListener("input", filtrar);
  sel.addEventListener("change", filtrar);
  filtrar();
}

// [1] SLIDESHOW: troca a classe "ativo", botões, indicadores e troca automática
const slides = document.querySelectorAll(".slide");
if (slides.length) {
  let at = 0; const ind = $("#indicadores");
  const bolas = [...slides].map((_, i) => { const b = document.createElement("button"); b.setAttribute("aria-label", "Slide " + (i + 1)); b.onclick = () => ir(i); ind.append(b); return b; });
  function ir(i) { at = (i + slides.length) % slides.length; slides.forEach((s, k) => { s.classList.toggle("ativo", k === at); bolas[k].classList.toggle("ativo", k === at); }); }
  $("#proximo").onclick = () => ir(at + 1);
  $("#anterior").onclick = () => ir(at - 1);
  setInterval(() => ir(at + 1), 5000);
  ir(0);
}

// [2] PARALLAX: cada camada anda uma fração da rolagem (data-velocidade)
const camadas = document.querySelectorAll("[data-velocidade]");
window.addEventListener("scroll", () => {
  const y = window.scrollY;
  camadas.forEach(c => c.style.transform = `translateY(${y * c.dataset.velocidade}px)`);
  topo.style.display = y > 400 ? "block" : "none"; // [14] voltar ao topo
});
topo.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// [3] SONS: música começa só após clique, volume baixo; sino ao comprar
const musica = new Audio("audio/musica-natal.wav"); musica.loop = true; musica.volume = 0.3;
const bm = $("#btn-musica");
bm.addEventListener("click", () => {
  if (musica.paused) { musica.play(); bm.textContent = "🔇 Pausar música"; }
  else { musica.pause(); bm.textContent = "🎵 Tocar música"; }
});
const sino = () => { const s = new Audio("audio/sino.wav"); s.volume = 0.5; s.play(); };

// [6] CARRINHO com localStorage
let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
function atualizar() {
  $("#qtd-carrinho").textContent = carrinho.length;
  const t = $("#total-carrinho");
  if (t) {
    t.textContent = preco(carrinho.reduce((s, p) => s + p.preco, 0));
    $("#itens-carrinho").innerHTML = carrinho.map((p, i) => `<li>${p.nome} · ${preco(p.preco)} <button class="remover" data-i="${i}" aria-label="Remover">✕</button></li>`).join("") || "<li>Seu carrinho está vazio.</li>";
  }
}
const salvar = () => { localStorage.setItem("carrinho", JSON.stringify(carrinho)); atualizar(); };

// [10] MODAL / LIGHTBOX
const modal = $("#modal");
const abrirModal = h => { $("#modal-corpo").innerHTML = h; modal.classList.add("aberto"); };
const fecharModal = () => modal.classList.remove("aberto");
if (modal) {
  modal.addEventListener("click", e => { if (e.target === modal || e.target.id === "fechar") fecharModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") fecharModal(); });
}

// Delegação de evento: os botões são criados pelo JS, então escutamos o documento
document.addEventListener("click", e => {
  const b = e.target;
  if (b.classList.contains("btn-comprar")) { carrinho.push(achar(b.dataset.id)); salvar(); sino(); }
  if (b.classList.contains("remover")) { carrinho.splice(b.dataset.i, 1); salvar(); }
  if (b.id === "limpar") { carrinho = []; salvar(); }
  if (b.classList.contains("btn-detalhe")) {
    const p = achar(b.dataset.id);
    abrirModal(`${foto(p)}<h2>${p.nome}</h2><p>${p.descricao}</p><p>Categoria: ${p.categoria}</p><strong>${preco(p.preco)}</strong>`);
  }
  if (b.dataset.lightbox) abrirModal(`<img src="${b.dataset.lightbox}" alt="${b.alt}">`);
});

// Galeria (lightbox)
const gal = $("#galeria-grid");
if (gal) gal.innerHTML = produtos.slice(0, 20).map(p => foto(p, `data-lightbox="${p.imagem}" loading="lazy"`)).join("");

// [7] CONTAGEM REGRESSIVA até o Natal (mês 11 = dezembro)
const cg = $("#contagem");
if (cg) {
  const contar = () => {
    const agora = new Date(); let natal = new Date(agora.getFullYear(), 11, 25);
    if (agora > natal) natal = new Date(agora.getFullYear() + 1, 11, 25);
    const f = natal - agora;
    cg.textContent = `${Math.floor(f / 864e5)}d ${Math.floor(f / 36e5) % 24}h ${Math.floor(f / 6e4) % 60}min ${Math.floor(f / 1000) % 60}s para o Natal`;
  };
  setInterval(contar, 1000); contar();
}

// [8] VALIDAÇÃO DO FORMULÁRIO
const form = $("#form-contato");
if (form) form.addEventListener("submit", e => {
  e.preventDefault();
  const msg = $("#mensagem-form"), v = id => document.getElementById(id).value.trim();
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v("email"));
  let erro = "";
  if (!v("nome")) erro = "Digite seu nome.";
  else if (!ok) erro = "Digite um e-mail válido, como nome@exemplo.com.";
  else if (!v("assunto")) erro = "Digite o assunto.";
  else if (v("mensagem").length < 10) erro = "A mensagem precisa ter pelo menos 10 caracteres.";
  msg.className = erro ? "erro" : "ok";
  msg.textContent = erro || `Obrigado, ${v("nome")}! Sua mensagem foi enviada.`;
  if (!erro) form.reset();
});

// [9] MENU HAMBÚRGUER
$(".btn-menu").addEventListener("click", () => $(".menu").classList.toggle("aberto"));

// [13] ANIMAÇÃO AO ROLAR (IntersectionObserver)
const obs = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) en.target.classList.add("visivel"); }));
document.querySelectorAll(".revelar").forEach(el => obs.observe(el));

// [12] MODO CLARO/ESCURO salvo no localStorage
if (localStorage.getItem("tema") === "noite") document.body.classList.add("noite");
$("#btn-tema").addEventListener("click", () => {
  document.body.classList.toggle("noite");
  localStorage.setItem("tema", document.body.classList.contains("noite") ? "noite" : "dia");
});

// [11] NEVE em canvas
const cv = document.createElement("canvas"); cv.id = "neve"; document.body.append(cv);
const cx = cv.getContext("2d");
const ajustar = () => { cv.width = innerWidth; cv.height = innerHeight; };
ajustar(); addEventListener("resize", ajustar);
const flocos = Array.from({ length: 70 }, () => ({ x: Math.random() * innerWidth, y: Math.random() * innerHeight, r: Math.random() * 3 + 1, v: Math.random() + 0.5 }));
(function animar() {
  cx.clearRect(0, 0, cv.width, cv.height); cx.fillStyle = "#fff"; cx.beginPath();
  flocos.forEach(f => { f.y += f.v; f.x += Math.sin(f.y / 40) * 0.5; if (f.y > cv.height) { f.y = -5; f.x = Math.random() * cv.width; } cx.moveTo(f.x, f.y); cx.arc(f.x, f.y, f.r, 0, 7); });
  cx.fill(); requestAnimationFrame(animar);
})();

atualizar();
