// Lista dos 50 produtos.
// Algumas fotos têm nome imagem_*.jpg, as outras seguem o nome do produto.
// Se uma foto não carregar, aparece a sem-foto.svg.
const produtos = [
  {
    "id": 1,
    "nome": "Panetone Tradicional",
    "categoria": "Panetones",
    "preco": 39.9,
    "imagem": "img/produtos/imagem_panetone_tradicional.jpg",
    "descricao": "O clássico de sempre, com frutas cristalizadas e uvas-passas.",
    "destaque": true
  },
  {
    "id": 2,
    "nome": "Panetone Trufado",
    "categoria": "Panetones",
    "preco": 59.9,
    "imagem": "img/produtos/panetone-trufado.jpg",
    "descricao": "Massa macia recheada com trufa de chocolate.",
    "destaque": false
  },
  {
    "id": 3,
    "nome": "Panetone de Nozes",
    "categoria": "Panetones",
    "preco": 54.9,
    "imagem": "img/produtos/panetone-de-nozes.jpg",
    "descricao": "Cheio de nozes picadas, com casquinha dourada por cima.",
    "destaque": false
  },
  {
    "id": 4,
    "nome": "Chocotone Clássico",
    "categoria": "Panetones",
    "preco": 49.9,
    "imagem": "img/produtos/chocotone-classico.jpg",
    "descricao": "Massa de chocolate com gotas de chocolate ao leite.",
    "destaque": false
  },
  {
    "id": 5,
    "nome": "Panetone de Pistache",
    "categoria": "Panetones",
    "preco": 69.9,
    "imagem": "img/produtos/panetone-de-pistache.jpg",
    "descricao": "Recheio de creme de pistache e pedaços da castanha.",
    "destaque": false
  },
  {
    "id": 6,
    "nome": "Panetone de Doce de Leite",
    "categoria": "Panetones",
    "preco": 52.9,
    "imagem": "img/produtos/panetone-de-doce-de-leite.jpg",
    "descricao": "Massa fofinha com ribbons de doce de leite.",
    "destaque": false
  },
  {
    "id": 7,
    "nome": "Panetone de Frutas",
    "categoria": "Panetones",
    "preco": 44.9,
    "imagem": "img/produtos/panetone-de-frutas.jpg",
    "descricao": "Versão com mix de frutas secas, mais leve que o tradicional.",
    "destaque": false
  },
  {
    "id": 8,
    "nome": "Panetone de Cereja",
    "categoria": "Panetones",
    "preco": 57.9,
    "imagem": "img/produtos/imagem_panetone_cereja.jpg",
    "descricao": "Cerejas em calda dentro da massa e por cima.",
    "destaque": true
  },
  {
    "id": 9,
    "nome": "Panetone de Laranja",
    "categoria": "Panetones",
    "preco": 47.9,
    "imagem": "img/produtos/panetone-de-laranja.jpg",
    "descricao": "Massa com raspas de laranja e casca cristalizada.",
    "destaque": false
  },
  {
    "id": 10,
    "nome": "Mini Panetone Pack",
    "categoria": "Panetones",
    "preco": 29.9,
    "imagem": "img/produtos/mini-panetone-pack.jpg",
    "descricao": "Cinco mini panetones tradicionais, bons para dividir ou presentear.",
    "destaque": false
  },
  {
    "id": 11,
    "nome": "Biscoito de Gengibre",
    "categoria": "Biscoitos",
    "preco": 12.5,
    "imagem": "img/produtos/biscoito-de-gengibre.jpg",
    "descricao": "Crocante, com bastante gengibre e decoração feita à mão.",
    "destaque": false
  },
  {
    "id": 12,
    "nome": "Biscoito de Canela",
    "categoria": "Biscoitos",
    "preco": 11.9,
    "imagem": "img/produtos/biscoito-de-canela.jpg",
    "descricao": "Biscoito amanteigado com canela e açúcar por cima.",
    "destaque": false
  },
  {
    "id": 13,
    "nome": "Biscoito Amanteigado",
    "categoria": "Biscoitos",
    "preco": 13.9,
    "imagem": "img/produtos/biscoito-amanteigado.jpg",
    "descricao": "Derrete na boca. Só manteiga, farinha e açúcar.",
    "destaque": false
  },
  {
    "id": 14,
    "nome": "Boneco de Neve de Baunilha",
    "categoria": "Biscoitos",
    "preco": 14.5,
    "imagem": "img/produtos/boneco-de-neve-de-baunilha.jpg",
    "descricao": "Biscoito de baunilha decorado com glacê branco.",
    "destaque": false
  },
  {
    "id": 15,
    "nome": "Estrelinhas Douradas",
    "categoria": "Biscoitos",
    "preco": 12.9,
    "imagem": "img/produtos/imagem_estrelinhas_douradas.jpg",
    "descricao": "Biscoitinhos em formato de estrela com cobertura dourada.",
    "destaque": true
  },
  {
    "id": 16,
    "nome": "Biscoito de Chocolate",
    "categoria": "Biscoitos",
    "preco": 15.9,
    "imagem": "img/produtos/biscoito-de-chocolate.jpg",
    "descricao": "Massa de cacau com pedaços de chocolate meio amargo.",
    "destaque": false
  },
  {
    "id": 17,
    "nome": "Biscoito de Limão",
    "categoria": "Biscoitos",
    "preco": 12.5,
    "imagem": "img/produtos/biscoito-de-limao.jpg",
    "descricao": "Biscoito cítrico com glacê de limão.",
    "destaque": false
  },
  {
    "id": 18,
    "nome": "Biscoito de Castanha",
    "categoria": "Biscoitos",
    "preco": 16.9,
    "imagem": "img/produtos/biscoito-de-castanha.jpg",
    "descricao": "Massa com castanhas trituradas, textura mais densa.",
    "destaque": false
  },
  {
    "id": 19,
    "nome": "Cookies Natalinos",
    "categoria": "Biscoitos",
    "preco": 18.9,
    "imagem": "img/produtos/cookies-natalinos.jpg",
    "descricao": "Cookies grandes com gotas de chocolate e frutas vermelhas.",
    "destaque": false
  },
  {
    "id": 20,
    "nome": "Bengalinhas Doces",
    "categoria": "Biscoitos",
    "preco": 9.9,
    "imagem": "img/produtos/bengalinhas-doces.jpg",
    "descricao": "Bengalinhas de açúcar nas cores do Natal.",
    "destaque": false
  },
  {
    "id": 21,
    "nome": "Bolo de Nozes",
    "categoria": "Bolos e Tortas",
    "preco": 79.9,
    "imagem": "img/produtos/bolo-de-nozes.jpg",
    "descricao": "Bolo úmido com nozes na massa e cobertura de caramelo.",
    "destaque": false
  },
  {
    "id": 22,
    "nome": "Torta de Maçã",
    "categoria": "Bolos e Tortas",
    "preco": 64.9,
    "imagem": "img/produtos/imagem_torta_maca.jpg",
    "descricao": "Maçã com canela sobre massa amanteigada.",
    "destaque": true
  },
  {
    "id": 23,
    "nome": "Bolo Floresta Negra",
    "categoria": "Bolos e Tortas",
    "preco": 89.9,
    "imagem": "img/produtos/bolo-floresta-negra.jpg",
    "descricao": "Chocolate, cerejas e chantilly em camadas.",
    "destaque": false
  },
  {
    "id": 24,
    "nome": "Bolo da Rena Rudolph",
    "categoria": "Bolos e Tortas",
    "preco": 74.9,
    "imagem": "img/produtos/bolo-da-rena-rudolph.jpg",
    "descricao": "Bolo de chocolate decorado com a rena do Papai Noel.",
    "destaque": false
  },
  {
    "id": 25,
    "nome": "Torta de Limão",
    "categoria": "Bolos e Tortas",
    "preco": 59.9,
    "imagem": "img/produtos/torta-de-limao.jpg",
    "descricao": "Base crocante, creme de limão e cobertura de merengue.",
    "destaque": false
  },
  {
    "id": 26,
    "nome": "Bolo de Cenoura Natalino",
    "categoria": "Bolos e Tortas",
    "preco": 54.9,
    "imagem": "img/produtos/bolo-de-cenoura-natalino.jpg",
    "descricao": "Bolo de cenoura com cobertura de chocolate e enfeites de Natal.",
    "destaque": false
  },
  {
    "id": 27,
    "nome": "Rocambole de Natal",
    "categoria": "Bolos e Tortas",
    "preco": 49.9,
    "imagem": "img/produtos/rocambole-de-natal.jpg",
    "descricao": "Rocambole recheado com creme e goiabada, enrolado à mão.",
    "destaque": false
  },
  {
    "id": 28,
    "nome": "Bolo Red Velvet",
    "categoria": "Bolos e Tortas",
    "preco": 84.9,
    "imagem": "img/produtos/bolo-red-velvet.jpg",
    "descricao": "Massa vermelha com cobertura de cream cheese.",
    "destaque": false
  },
  {
    "id": 29,
    "nome": "Torta Holandesa",
    "categoria": "Bolos e Tortas",
    "preco": 69.9,
    "imagem": "img/produtos/imagem_torta_holandesa.jpg",
    "descricao": "Torta com creme holandês e cobertura de chocolate.",
    "destaque": true
  },
  {
    "id": 30,
    "nome": "Bolo de Especiarias",
    "categoria": "Bolos e Tortas",
    "preco": 62.9,
    "imagem": "img/produtos/bolo-de-especiarias.jpg",
    "descricao": "Bolo com canela, cravo e noz-moscada, bem aromático.",
    "destaque": false
  },
  {
    "id": 31,
    "nome": "Cesta Noite Feliz",
    "categoria": "Cestas e Kits",
    "preco": 129.9,
    "imagem": "img/produtos/cesta-noite-feliz.jpg",
    "descricao": "Cesta com panetone, biscoitos, chocolate e geleia.",
    "destaque": false
  },
  {
    "id": 32,
    "nome": "Cesta Papai Noel",
    "categoria": "Cestas e Kits",
    "preco": 159.9,
    "imagem": "img/produtos/cesta-papai-noel.jpg",
    "descricao": "Cesta grande com panetone, bolo, biscoitos e bebida quente.",
    "destaque": false
  },
  {
    "id": 33,
    "nome": "Kit Café da Manhã",
    "categoria": "Cestas e Kits",
    "preco": 119.9,
    "imagem": "img/produtos/kit-cafe-da-manha.jpg",
    "descricao": "Kit com pães doces, geleia, bolo e café para a manhã de Natal.",
    "destaque": false
  },
  {
    "id": 34,
    "nome": "Kit Ceia Completa",
    "categoria": "Cestas e Kits",
    "preco": 189.9,
    "imagem": "img/produtos/kit-ceia-completa.jpg",
    "descricao": "Tudo para a ceia: panetone, torta, biscoitos e bebidas.",
    "destaque": false
  },
  {
    "id": 35,
    "nome": "Cesta Mini Estrela",
    "categoria": "Cestas e Kits",
    "preco": 79.9,
    "imagem": "img/produtos/cesta-mini-estrela.jpg",
    "descricao": "Cesta pequena com biscoitos de estrela e um chocolate. Boa para lembrancinha.",
    "destaque": false
  },
  {
    "id": 36,
    "nome": "Kit Presente Doce",
    "categoria": "Cestas e Kits",
    "preco": 99.9,
    "imagem": "img/produtos/imagem_kit_presente_doce.jpg",
    "descricao": "Kit com doces variados em caixa de presente.",
    "destaque": true
  },
  {
    "id": 37,
    "nome": "Cesta Luxo Dourada",
    "categoria": "Cestas e Kits",
    "preco": 249.9,
    "imagem": "img/produtos/cesta-luxo-dourada.jpg",
    "descricao": "A cesta mais completa da loja, com embalagem dourada.",
    "destaque": false
  },
  {
    "id": 38,
    "nome": "Kit Chocolates",
    "categoria": "Cestas e Kits",
    "preco": 109.9,
    "imagem": "img/produtos/kit-chocolates.jpg",
    "descricao": "Seleção de barras e bombons de chocolates variados.",
    "destaque": false
  },
  {
    "id": 39,
    "nome": "Cesta Família",
    "categoria": "Cestas e Kits",
    "preco": 219.9,
    "imagem": "img/produtos/cesta-familia.jpg",
    "descricao": "Cesta grande, pensada para a família toda na mesa.",
    "destaque": false
  },
  {
    "id": 40,
    "nome": "Kit Lanche Natalino",
    "categoria": "Cestas e Kits",
    "preco": 89.9,
    "imagem": "img/produtos/kit-lanche-natalino.jpg",
    "descricao": "Kit de lanche com bolo, biscoitos e suco.",
    "destaque": false
  },
  {
    "id": 41,
    "nome": "Chocolate Quente Cremoso",
    "categoria": "Bebidas e Chocolates",
    "preco": 24.9,
    "imagem": "img/produtos/chocolate-quente-cremoso.jpg",
    "descricao": "Chocolate quente espesso, com marshmallow.",
    "destaque": false
  },
  {
    "id": 42,
    "nome": "Chocolate Belga ao Leite",
    "categoria": "Bebidas e Chocolates",
    "preco": 32.9,
    "imagem": "img/produtos/chocolate-belga-ao-leite.jpg",
    "descricao": "Barra de chocolate belga ao leite.",
    "destaque": false
  },
  {
    "id": 43,
    "nome": "Cacau Trufado",
    "categoria": "Bebidas e Chocolates",
    "preco": 28.9,
    "imagem": "img/produtos/imagem_cacau_trufado.jpg",
    "descricao": "Cacau em pó com pedaços de trufa, para misturar no leite.",
    "destaque": true
  },
  {
    "id": 44,
    "nome": "Café Natalino",
    "categoria": "Bebidas e Chocolates",
    "preco": 27.9,
    "imagem": "img/produtos/cafe-natalino.jpg",
    "descricao": "Café com toque de canela e cravo.",
    "destaque": false
  },
  {
    "id": 45,
    "nome": "Chá de Canela e Maçã",
    "categoria": "Bebidas e Chocolates",
    "preco": 19.9,
    "imagem": "img/produtos/cha-de-canela-e-maca.jpg",
    "descricao": "Chá de canela com pedaços de maçã desidratada.",
    "destaque": false
  },
  {
    "id": 46,
    "nome": "Suco de Uva Festivo",
    "categoria": "Bebidas e Chocolates",
    "preco": 22.9,
    "imagem": "img/produtos/suco-de-uva-festivo.jpg",
    "descricao": "Suco de uva integral, para brindar sem álcool.",
    "destaque": false
  },
  {
    "id": 47,
    "nome": "Ponche Natalino sem Álcool",
    "categoria": "Bebidas e Chocolates",
    "preco": 26.9,
    "imagem": "img/produtos/ponche-natalino-sem-alcool.jpg",
    "descricao": "Ponche de frutas com especiarias, servido quente ou gelado.",
    "destaque": false
  },
  {
    "id": 48,
    "nome": "Leite de Amêndoas Quente",
    "categoria": "Bebidas e Chocolates",
    "preco": 21.9,
    "imagem": "img/produtos/leite-de-amendoas-quente.jpg",
    "descricao": "Leite de amêndoas aquecido com baunilha, opção sem lactose.",
    "destaque": false
  },
  {
    "id": 49,
    "nome": "Barra de Chocolate Meio Amargo",
    "categoria": "Bebidas e Chocolates",
    "preco": 18.9,
    "imagem": "img/produtos/barra-de-chocolate-meio-amargo.jpg",
    "descricao": "Barra de chocolate meio amargo, para quem gosta menos doce.",
    "destaque": false
  },
  {
    "id": 50,
    "nome": "Bombons de Natal",
    "categoria": "Bebidas e Chocolates",
    "preco": 34.9,
    "imagem": "img/produtos/imagem_bombons_natal.jpg",
    "descricao": "Caixa com bombons de sabores variados.",
    "destaque": true
  }
];
